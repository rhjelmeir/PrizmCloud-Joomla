<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Editors-xtd.prizmcloudviewer
 *
 * @copyright   Copyright (C) 2013 Accusoft Corporation. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Editor PrizmCloud Viewer button
 *
 * @package     Joomla.Plugin
 * @subpackage  Editors-xtd.prizmcloudviewer
 * @since       1.5
 */
class PlgButtonPrizmcloudviewer extends JPlugin
{
	/**
	 * Load the language file on instantiation.
	 *
	 * @var    boolean
	 * @since  3.1
	 */
	protected $autoloadLanguage = true;

	/**
	 * Display the button
	 *
	 * @return array A two element array of (imageName, textToInsert)
	 */
	public function onDisplay($name)
	{
		JHtml::_('behavior.modal');
		
		$app     = JFactory::getApplication();
		$doc 	 =& JFactory::getDocument();
		$appname = $app->getName();
		$apppath = $appname == 'site' ? '' : '../';
		$link = $apppath . 'plugins/editors-xtd/prizmcloudviewer/prizmcloudviewer-dialog.php?app='.$appname.'&amp;e_name='.$name;

		$button = new JObject;
		$button->modal = true;
		$button->link  = $link;
		$button->text  = JText::_('PrizmCloud Viewer');
		$button->name  = 'copy';
		$button->options = "{handler: 'iframe', size: {x: 500, y: 400}}";

		return $button;
	}
}
