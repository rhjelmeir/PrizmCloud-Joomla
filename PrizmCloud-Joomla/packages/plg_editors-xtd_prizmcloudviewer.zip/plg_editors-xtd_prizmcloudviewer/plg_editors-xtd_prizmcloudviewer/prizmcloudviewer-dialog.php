<?php
/**
 * @version 1.3 - GroupDocs Viewer Pulgin
 * @package plugins
 * @copyright Copyright (C) 2012 GroupDocs. All rights reserved.
 * @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */
// Set flag that this is a parent file
define( '_JEXEC', 1 );

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

define( 'DS', DIRECTORY_SEPARATOR );
define('JPATH_BASE', dirname(__FILE__).DS.'..'.DS.'..'.DS.'..' );

require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );


JDEBUG ? $_PROFILER->mark( 'afterLoad' ) : null;

 // CREATE THE APPLICATION
$app = JRequest::getString('app', 'site');

$app = $app == 'site' ? 'site' : ($app == 'administrator' ? 'administrator' : 'site');
$app_path = $app == 'site' ? '../../..' : '../../../administrator';

$mainframe =& JFactory::getApplication($app);
$doc =& JFactory::getDocument();

/** @var jlanguage $lang */
//$lang =& JFactory::getLanguage();
//$lang->load('plg_editors-xtd_prizmcloudviewer', realpath(JPATH_BASE.DS.'administrator'));

jimport( 'joomla.filesystem.path' ) ;
jimport( 'joomla.html.parameter' ) ;

jimport( 'joomla.plugin.plugin' ) ;
jimport( 'joomla.plugin.helper' ) ;
$plugin = JPluginHelper::getPlugin( 'editors-xtd', 'prizmcloudviewer' ) ;

if( empty( $plugin ->params )) {$plugin= new stdClass; $plugin->params = ''; }
//$pluginParams = new JParameter( $plugin->params ) ;

//$userId = $pluginParams->get('prizmcloud_key');
/*//$this->params->get('paramname', 'paramvalue');
//$privateKey = $pluginParams->get('groupdocs_api_key');


if(!empty($_POST) or !empty($_FILES)) {
	$file = $_FILES['file'];
	$error_text = true; // Show text or number
	define("UPLOAD_ERR_EMPTY",5);
	if($file['size'] == 0 && $file['error'] == 0){
		$file['error'] = 5;
	}
	$upload_errors = array(
		UPLOAD_ERR_OK        => "No errors.",
		UPLOAD_ERR_INI_SIZE    => "Larger than upload_max_filesize.",
		UPLOAD_ERR_FORM_SIZE    => "Larger than form MAX_FILE_SIZE.",
		UPLOAD_ERR_PARTIAL    => "Partial upload.",
		UPLOAD_ERR_NO_FILE        => "No file.",
		UPLOAD_ERR_NO_TMP_DIR    => "No temporary directory.",
		UPLOAD_ERR_CANT_WRITE    => "Can't write to disk.",
		UPLOAD_ERR_EXTENSION     => "File upload stopped by extension.",
		UPLOAD_ERR_EMPTY        => "File is empty." // add this to avoid an offset
	);
	// error: report what PHP says went wrong
	$err = ($error_text) ? $upload_errors[$file['error']] : $file['error'] ;

	if($file['error'] !== 0) {
		echo "<div class='red'>" . $err . "</div>";
	} else {
		include_once(dirname(__FILE__) . '/tree_viewer/lib/groupdocs-php/ApiClient.php');
		include_once(dirname(__FILE__) . '/tree_viewer/lib/groupdocs-php/StorageApi.php');
		include_once(dirname(__FILE__) . '/tree_viewer/lib/groupdocs-php/GroupDocsRequestSigner.php');

		$tmp_name = $_FILES["file"]["tmp_name"];
		$name = $_FILES["file"]["name"];
	 
		$private_key = trim($_POST['pkey']); 
		$user_id = trim($_POST['uid']); 
		
		$fs = FileStream::fromFile($tmp_name);
		$signer = new GroupDocsRequestSigner($private_key);
		$ApiClient = new ApiClient($signer);
		$ApiStorage = new StorageApi($ApiClient);

		try{
			$result = $ApiStorage->Upload($user_id, $name, 'uploaded', $fs);
		} catch (Exception $e) {
			echo $e->getMessage();
			exit();
		}

		echo"<script>
		  window.parent.jInsertEditorText('{GroupDocs guid=\"". @$result->result->guid ."\" width=\"".intval($_POST['width'])."\" height=\"".intval($_POST['height'])."\"}', 'jform_articletext');
		  window.parent.SqueezeBox.close();
		</script>"; die;
	}
}
*/
 ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo JText::_('PrizmCloud Document Viewer Settings'); ?></title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <!--link rel="stylesheet" type="text/css" href="dialog.css" /-->
	<link rel="stylesheet" href="/joomla/administrator/templates/isis/css/template.css" type="text/css">
	<script src="/joomla/media/jui/js/jquery.min.js" type="text/javascript"></script>
	<script src="/joomla/media/jui/js/jquery-noconflict.js" type="text/javascript"></script>
	<script src="/joomla/media/jui/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="/joomla/templates/isis/js/template.js" type="text/javascript"></script>
	<!--script type="text/javascript" src="helper.js"></script-->
    <script type="text/javascript" src="jscolor.js"></script>
	<!--[if lt IE 9]>
		<script src="../media/jui/js/html5.js"></script>
	<![endif]-->
	<script type="text/javascript">
	function insertPrizmcloud() {
		var vtype = document.getElementById("prizm_vtype").value;
		if (vtype != '') {
			vtype = "vtype=\""+vtype+"\" ";
		}
		var doc_url = document.getElementById("prizm_doc_url").value;
		if (doc_url != '') {
			doc_url = "doc_url=\""+doc_url+"\" ";
		}
		var vheight = document.getElementById("prizm_height").value;
		if (vheight != '') {
			vheight = "vheight=\""+vheight+"\" ";
		}
		var vwidth = document.getElementById("prizm_width").value;
		if (vwidth != '') {
			vwidth = "vwidth=\""+vwidth+"\" ";
		}
		var print_button = document.getElementById("prizm_print_button").value;
		if (print_button != '') {
			print_button = "print_button=\""+print_button+"\" ";
		}
		var toolbar_color = document.getElementById("prizm_toolbar_color").value;
		if (toolbar_color != '') {
			toolbar_color = "toolbar_color=\""+toolbar_color+"\" ";
		}

		var tag = "{PrizmCloud-viewer " + vtype + doc_url + vheight + vwidth + print_button + toolbar_color + "}";
		window.parent.jInsertEditorText(tag, 'jform_articletext');
		window.parent.SqueezeBox.close();
		return false;
	}
  </script>
</head>
<body>
<form action='' name="prizmcloud" method='post' id="prizmcloud_viewer">
<fieldset class="prizmcloud_viewer_dialog">
	<h2>PrizmCloud Document Viewer Settings</h2>
	<table width="100%">
		<tr>
			<td class="key" align="right"><label for="vtype">Viewer Type</label></td>
			<td>
				<select name="vtype" id="prizm_vtype" class="input">
					<option value="html5">html5</option>
					<option value="flash">flash</option>
				</select>
			</td>
		</tr>
		<tr>
			<td class="key" align="right"><label for="doc_url">Document Url</label></td>
			<td><input id="prizm_doc_url" name='doc_url' type='text' value='<?php echo $doc_url; ?>'></td>
		</tr>
		<tr>
			<td class="key" align="right"><label for="vheight">Height</label></td>
			<td><input id='prizm_height' name='vheight' value='600' size='5' type='text' style='text-align:right'>px</td>
		</tr>
		<tr>
			<td class="key" align="right"><label for="vwidth">Width</label></td>
			<td><input id='prizm_width' name='vwidth' value='500' size='5' type='text' style='text-align:right'>px</td>
		</tr>
		<tr>
			<td class="key" align="right"><label for="print_button">Print Button</label></td>
			<td>
				<select name="print_button" id="prizm_print_button" class="input">
					<option value="Yes">Yes</option>
					<option value="No">No</option>
				</select></td>
		</tr>
		<tr>
			<td>Toolbar Color</td>
			<td><input id='prizm_toolbar_color' name='toolbar_color' class="color" value='CCCCCC' type='text'></td>
		</tr>
	</table>
</fieldset>
</form>
<table width="100%">
	<tr>
		<td colspan="2" align="left" valign="bottom" nowrap>
			<input type="submit" value="<?php echo JText::_('Insert') ?>" onClick="insertPrizmcloud();" class="bt">
			<?php /*input type="button" value="<?php echo JText::_('Cancel') ?>" onClick="InsertHtmlDialogcancelClick()" class="bt"> */ ?>
		</td>
	</tr>
</table>
</body>
</html>